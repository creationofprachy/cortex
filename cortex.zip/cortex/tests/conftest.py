"""Shared pytest fixtures.

Cortex reads its data paths from environment variables at import time, so
each test reloads the relevant modules after pointing them at a fresh
temporary directory. This keeps tests isolated from a developer's real
document index and from each other.
"""
import importlib
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


@pytest.fixture()
def app_modules(tmp_path, monkeypatch):
    """Return a fresh set of Cortex modules bound to an isolated data dir."""
    monkeypatch.setenv("CORTEX_DATA_DIR", str(tmp_path / "data"))
    monkeypatch.setenv("CORTEX_DOCUMENTS_DIR", str(tmp_path / "data" / "documents"))
    monkeypatch.setenv("CORTEX_INDEX_DIR", str(tmp_path / "data" / "index"))
    monkeypatch.setenv("CORTEX_DB_PATH", str(tmp_path / "data" / "cortex.db"))

    from app import config, database, embeddings, graph, ingestion, search

    for module in (config, database, embeddings, ingestion, search, graph):
        importlib.reload(module)

    database.init_db()

    return {
        "config": config,
        "database": database,
        "embeddings": embeddings,
        "ingestion": ingestion,
        "search": search,
        "graph": graph,
    }
