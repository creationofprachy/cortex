CORPUS = [
    (1, "The mitochondria is the powerhouse of the cell and drives cellular respiration."),
    (2, "Neural networks learn representations through layers of weighted connections."),
    (3, "Cellular respiration in mitochondria converts glucose into usable energy."),
    (4, "Deep learning models such as convolutional networks process image data."),
]


def _seed_documents(database, ingestion, conn, entries):
    chunk_ids = []
    for i, (_, text) in enumerate(entries):
        doc_id = database.insert_document(conn, f"doc{i}.txt", f"Document {i}", len(text))
        database.insert_chunks(conn, doc_id, [text])
    for row in database.fetch_all_chunks(conn):
        chunk_ids.append(row["chunk_id"])
    return chunk_ids


def test_search_ranks_semantically_related_chunk_higher(app_modules):
    database = app_modules["database"]
    search_module = app_modules["search"]
    embeddings = app_modules["embeddings"]

    with database.db_session() as conn:
        _seed_documents(database, app_modules["ingestion"], conn, CORPUS)
        rows = database.fetch_all_chunks(conn)

    index = embeddings.SemanticIndex()
    index.fit([r["chunk_id"] for r in rows], [r["text"] for r in rows])

    with database.db_session() as conn:
        results = search_module.search(conn, index, "mitochondria energy production", top_k=4)

    assert results, "expected at least one search result"
    top_titles = {results[0]["document_title"], results[1]["document_title"]}
    # The two mitochondria/respiration chunks should outrank the neural-network ones.
    assert top_titles == {"Document 0", "Document 2"}


def test_search_returns_empty_list_for_blank_query(app_modules):
    database = app_modules["database"]
    search_module = app_modules["search"]
    embeddings = app_modules["embeddings"]

    index = embeddings.SemanticIndex()
    index.fit([1], ["some content"])

    with database.db_session() as conn:
        assert search_module.search(conn, index, "   ") == []


def test_search_returns_empty_list_when_index_not_ready(app_modules):
    database = app_modules["database"]
    search_module = app_modules["search"]
    embeddings = app_modules["embeddings"]

    index = embeddings.SemanticIndex()  # never fit
    with database.db_session() as conn:
        assert search_module.search(conn, index, "anything") == []


def test_semantic_index_save_and_load_roundtrip(app_modules):
    embeddings = app_modules["embeddings"]

    index = embeddings.SemanticIndex()
    index.fit([10, 20], ["red apples and green apples", "fast cars and racing engines"])
    index.save()

    loaded = embeddings.SemanticIndex()
    assert loaded.load() is True
    assert loaded.vectors.shape == index.vectors.shape
    assert list(loaded.chunk_ids) == [10, 20]
