"""End-to-end tests through the FastAPI layer using a temp data directory."""
import importlib

import pytest
from fastapi.testclient import TestClient


@pytest.fixture()
def client(app_modules, tmp_path, monkeypatch):
    from app import main as main_module

    importlib.reload(main_module)

    with TestClient(main_module.app) as test_client:
        yield test_client


def test_status_starts_empty(client):
    res = client.get("/api/status")
    assert res.status_code == 200
    body = res.json()
    assert body["document_count"] == 0
    assert body["index_ready"] is False


def test_ingest_search_and_graph_roundtrip(client, tmp_path):
    doc_a = ("astronomy.txt", b"Black holes warp spacetime and trap even light near the event horizon.")
    doc_b = ("physics.txt", b"The event horizon of a black hole marks the boundary where light cannot escape.")
    doc_c = ("cooking.txt", b"Simmer the tomato sauce for twenty minutes and season with fresh basil.")

    for filename, content in (doc_a, doc_b, doc_c):
        res = client.post(
            "/api/ingest",
            files={"file": (filename, content, "text/plain")},
        )
        assert res.status_code == 200, res.text

    status = client.get("/api/status").json()
    assert status["document_count"] == 3
    assert status["index_ready"] is True

    search_res = client.get("/api/search", params={"q": "black hole event horizon"})
    assert search_res.status_code == 200
    results = search_res.json()
    assert results, "expected search results"
    top_filenames = {r["filename"] for r in results[:2]}
    assert top_filenames == {"astronomy.txt", "physics.txt"}

    graph_res = client.get("/api/graph")
    assert graph_res.status_code == 200
    graph = graph_res.json()
    assert len(graph["nodes"]) == 3
    labels = {n["filename"] for n in graph["nodes"]}
    assert labels == {"astronomy.txt", "physics.txt", "cooking.txt"}


def test_ingest_rejects_unsupported_extension(client):
    res = client.post(
        "/api/ingest",
        files={"file": ("data.exe", b"binary junk", "application/octet-stream")},
    )
    assert res.status_code == 400


def test_ingest_rejects_duplicate_filename(client):
    content = b"Some unique research content about coral reef ecosystems."
    first = client.post("/api/ingest", files={"file": ("reefs.txt", content, "text/plain")})
    assert first.status_code == 200
    second = client.post("/api/ingest", files={"file": ("reefs.txt", content, "text/plain")})
    assert second.status_code == 409


def test_delete_document_removes_it_and_rebuilds_index(client):
    content = b"Temporary content about volcanic eruption patterns and lava flow."
    ingest_res = client.post("/api/ingest", files={"file": ("volcano.txt", content, "text/plain")})
    doc_id = ingest_res.json()["document_id"]

    delete_res = client.delete(f"/api/documents/{doc_id}")
    assert delete_res.status_code == 200

    docs = client.get("/api/documents").json()
    assert all(d["id"] != doc_id for d in docs)


def test_search_requires_nonempty_query(client):
    res = client.get("/api/search", params={"q": ""})
    assert res.status_code == 400
