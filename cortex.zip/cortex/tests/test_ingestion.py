import pytest


def test_chunk_text_splits_on_word_windows(app_modules):
    ingestion = app_modules["ingestion"]
    text = " ".join(f"word{i}" for i in range(500))
    chunks = ingestion.chunk_text(text, chunk_size_words=100, overlap_words=20)

    assert len(chunks) > 1
    # Overlap means consecutive chunks share trailing/leading words.
    first_words = chunks[0].split()
    second_words = chunks[1].split()
    assert first_words[-20:] == second_words[:20]


def test_chunk_text_empty_input_returns_no_chunks(app_modules):
    ingestion = app_modules["ingestion"]
    assert ingestion.chunk_text("   ") == []


def test_chunk_text_rejects_invalid_window_sizes(app_modules):
    ingestion = app_modules["ingestion"]
    with pytest.raises(ValueError):
        ingestion.chunk_text("some text here", chunk_size_words=10, overlap_words=10)


def test_derive_title_uses_first_nonempty_line(app_modules):
    ingestion = app_modules["ingestion"]
    text = "\n\n# My Research Notes\n\nBody text follows."
    assert ingestion.derive_title(text, fallback="fallback.txt") == "My Research Notes"


def test_derive_title_falls_back_when_text_is_blank(app_modules):
    ingestion = app_modules["ingestion"]
    assert ingestion.derive_title("   \n  ", fallback="fallback.txt") == "fallback.txt"


def test_extract_text_reads_plain_text_file(app_modules, tmp_path):
    ingestion = app_modules["ingestion"]
    file_path = tmp_path / "note.txt"
    file_path.write_text("hello world", encoding="utf-8")
    assert ingestion.extract_text(file_path) == "hello world"


def test_extract_text_rejects_unsupported_type(app_modules, tmp_path):
    ingestion = app_modules["ingestion"]
    file_path = tmp_path / "note.docx"
    file_path.write_text("irrelevant", encoding="utf-8")
    with pytest.raises(ingestion.UnsupportedFileType):
        ingestion.extract_text(file_path)
