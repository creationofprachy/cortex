def test_build_document_graph_links_similar_documents(app_modules):
    database = app_modules["database"]
    embeddings = app_modules["embeddings"]
    graph_module = app_modules["graph"]

    entries = [
        "The mitochondria is the powerhouse of the cell and drives cellular respiration.",
        "Cellular respiration in mitochondria converts glucose into usable energy for cells.",
        "Quarterly revenue grew as the sales team closed several enterprise contracts.",
    ]

    with database.db_session() as conn:
        for i, text in enumerate(entries):
            doc_id = database.insert_document(conn, f"doc{i}.txt", f"Document {i}", len(text))
            database.insert_chunks(conn, doc_id, [text])
        rows = database.fetch_all_chunks(conn)

    index = embeddings.SemanticIndex()
    index.fit([r["chunk_id"] for r in rows], [r["text"] for r in rows])

    with database.db_session() as conn:
        result = graph_module.build_document_graph(conn, index)

    assert len(result["nodes"]) == 3
    edge_pairs = {tuple(sorted((e["source"], e["target"]))) for e in result["edges"]}
    # The two biology documents should be linked; the unrelated sales doc should not be.
    node_by_label = {n["label"]: n["id"] for n in result["nodes"]}
    biology_pair = tuple(sorted((node_by_label["Document 0"], node_by_label["Document 1"])))
    assert biology_pair in edge_pairs


def test_build_document_graph_handles_empty_corpus(app_modules):
    database = app_modules["database"]
    embeddings = app_modules["embeddings"]
    graph_module = app_modules["graph"]

    index = embeddings.SemanticIndex()
    with database.db_session() as conn:
        result = graph_module.build_document_graph(conn, index)

    assert result == {"nodes": [], "edges": []}
