const API = "";

// --- Tab switching -----------------------------------------------------
document.querySelectorAll(".tab-btn").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab-btn").forEach((b) => b.classList.remove("active"));
    document.querySelectorAll(".panel").forEach((p) => p.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById(`panel-${btn.dataset.tab}`).classList.add("active");
    if (btn.dataset.tab === "graph") loadGraph();
    if (btn.dataset.tab === "library") loadDocuments();
  });
});

// --- Status pill ---------------------------------------------------------
async function refreshStatus() {
  try {
    const res = await fetch(`${API}/api/status`);
    const data = await res.json();
    document.getElementById("status-pill").textContent =
      `${data.document_count} docs · ${data.chunk_count} chunks indexed`;
  } catch (err) {
    document.getElementById("status-pill").textContent = "offline";
  }
}

// --- Search ---------------------------------------------------------------
const searchInput = document.getElementById("search-input");
const searchBtn = document.getElementById("search-btn");
const resultsEl = document.getElementById("search-results");
const emptyStateEl = document.getElementById("search-empty");

async function doSearch() {
  const q = searchInput.value.trim();
  if (!q) return;
  resultsEl.innerHTML = `<p class="empty-state">Searching...</p>`;
  emptyStateEl.style.display = "none";

  try {
    const res = await fetch(`${API}/api/search?q=${encodeURIComponent(q)}`);
    if (!res.ok) throw new Error(await res.text());
    const results = await res.json();

    if (results.length === 0) {
      resultsEl.innerHTML = `<p class="empty-state">No matches yet. Try different wording, or upload more documents.</p>`;
      return;
    }

    resultsEl.innerHTML = results
      .map(
        (r) => `
        <div class="result-card">
          <h3>${escapeHtml(r.document_title)}</h3>
          <div class="result-meta">
            <span>${escapeHtml(r.filename)}</span>
            <span>chunk #${r.chunk_index}</span>
            <span>similarity ${(r.score * 100).toFixed(1)}%</span>
          </div>
          <div class="result-snippet">${escapeHtml(r.snippet)}</div>
        </div>`
      )
      .join("");
  } catch (err) {
    resultsEl.innerHTML = `<p class="empty-state">Search failed: ${escapeHtml(String(err))}</p>`;
  }
}

searchBtn.addEventListener("click", doSearch);
searchInput.addEventListener("keydown", (e) => {
  if (e.key === "Enter") doSearch();
});

// --- Graph ------------------------------------------------------------
let network = null;

async function loadGraph() {
  const container = document.getElementById("graph-container");
  try {
    const res = await fetch(`${API}/api/graph`);
    const data = await res.json();

    const nodes = new vis.DataSet(
      data.nodes.map((n) => ({
        id: n.id,
        label: n.label.length > 28 ? n.label.slice(0, 28) + "..." : n.label,
        title: n.filename,
      }))
    );
    const edges = new vis.DataSet(
      data.edges.map((e) => ({
        from: e.source,
        to: e.target,
        value: e.weight,
        title: `similarity ${(e.weight * 100).toFixed(1)}%`,
      }))
    );

    const options = {
      nodes: {
        shape: "dot",
        size: 14,
        font: { color: "#ede7d8", face: "IBM Plex Mono" },
        color: { background: "#c79a3d", border: "#3e7c74" },
      },
      edges: {
        color: { color: "rgba(237,231,216,0.25)", highlight: "#57a89d" },
        smooth: { type: "continuous" },
        scaling: { min: 1, max: 6 },
      },
      physics: { stabilization: true, barnesHut: { gravitationalConstant: -8000 } },
      interaction: { hover: true },
    };

    if (network) network.destroy();
    network = new vis.Network(container, { nodes, edges }, options);
  } catch (err) {
    container.innerHTML = `<p class="empty-state">Could not load graph: ${escapeHtml(String(err))}</p>`;
  }
}

document.getElementById("refresh-graph-btn").addEventListener("click", loadGraph);

// --- Library / upload ---------------------------------------------------
const fileInput = document.getElementById("file-input");
const uploadMessage = document.getElementById("upload-message");
const docTableBody = document.getElementById("doc-table-body");

document.querySelector(".upload-label").addEventListener("click", (e) => {
  e.preventDefault();
  fileInput.click();
});

fileInput.addEventListener("change", async () => {
  const file = fileInput.files[0];
  if (!file) return;

  const formData = new FormData();
  formData.append("file", file);

  uploadMessage.textContent = `Uploading ${file.name}...`;
  uploadMessage.className = "";

  try {
    const res = await fetch(`${API}/api/ingest`, { method: "POST", body: formData });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Upload failed");

    uploadMessage.textContent = `Indexed "${data.title}" (${data.chunk_count} chunks).`;
    uploadMessage.className = "success";
    fileInput.value = "";
    loadDocuments();
    refreshStatus();
  } catch (err) {
    uploadMessage.textContent = `Error: ${err.message}`;
    uploadMessage.className = "error";
  }
});

async function loadDocuments() {
  const res = await fetch(`${API}/api/documents`);
  const docs = await res.json();

  if (docs.length === 0) {
    docTableBody.innerHTML = `<tr><td colspan="5" class="empty-state">No documents yet.</td></tr>`;
    return;
  }

  docTableBody.innerHTML = docs
    .map(
      (d) => `
      <tr>
        <td>${escapeHtml(d.title)}</td>
        <td>${escapeHtml(d.filename)}</td>
        <td>${new Date(d.added_at).toLocaleDateString()}</td>
        <td>${(d.char_count / 1000).toFixed(1)}k chars</td>
        <td><button class="delete-btn" data-id="${d.id}">Remove</button></td>
      </tr>`
    )
    .join("");

  docTableBody.querySelectorAll(".delete-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      await fetch(`${API}/api/documents/${btn.dataset.id}`, { method: "DELETE" });
      loadDocuments();
      refreshStatus();
    });
  });
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

// --- Init -----------------------------------------------------------------
refreshStatus();
loadDocuments();
