"""Central configuration, driven by environment variables with sane defaults."""
import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent

# All paths are relative to the project root and configurable via env vars,
# so the app never depends on a hardcoded absolute/local path.
DATA_DIR = Path(os.getenv("CORTEX_DATA_DIR", BASE_DIR / "data"))
DOCUMENTS_DIR = Path(os.getenv("CORTEX_DOCUMENTS_DIR", DATA_DIR / "documents"))
INDEX_DIR = Path(os.getenv("CORTEX_INDEX_DIR", DATA_DIR / "index"))
DB_PATH = Path(os.getenv("CORTEX_DB_PATH", DATA_DIR / "cortex.db"))

# Chunking
CHUNK_SIZE_WORDS = int(os.getenv("CORTEX_CHUNK_SIZE_WORDS", "180"))
CHUNK_OVERLAP_WORDS = int(os.getenv("CORTEX_CHUNK_OVERLAP_WORDS", "40"))

# Embedding model (LSA = TF-IDF + Truncated SVD, fully local, no downloads)
SVD_COMPONENTS = int(os.getenv("CORTEX_SVD_COMPONENTS", "128"))

# Graph construction
GRAPH_SIMILARITY_THRESHOLD = float(os.getenv("CORTEX_GRAPH_THRESHOLD", "0.35"))
GRAPH_MAX_EDGES_PER_NODE = int(os.getenv("CORTEX_GRAPH_MAX_EDGES", "5"))

# Search
DEFAULT_TOP_K = int(os.getenv("CORTEX_DEFAULT_TOP_K", "8"))

for _p in (DATA_DIR, DOCUMENTS_DIR, INDEX_DIR):
    _p.mkdir(parents=True, exist_ok=True)
