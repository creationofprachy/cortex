"""SQLite persistence layer. No ORM overhead -- the schema is small and stable."""
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path

from app.config import DB_PATH

SCHEMA = """
CREATE TABLE IF NOT EXISTS documents (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    filename TEXT NOT NULL,
    title TEXT NOT NULL,
    added_at TEXT NOT NULL,
    char_count INTEGER NOT NULL
);

CREATE TABLE IF NOT EXISTS chunks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    document_id INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    chunk_index INTEGER NOT NULL,
    text TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_chunks_document_id ON chunks(document_id);
"""


def get_connection() -> sqlite3.Connection:
    Path(DB_PATH).parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def init_db() -> None:
    with get_connection() as conn:
        conn.executescript(SCHEMA)


@contextmanager
def db_session():
    conn = get_connection()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def insert_document(conn: sqlite3.Connection, filename: str, title: str, char_count: int) -> int:
    cur = conn.execute(
        "INSERT INTO documents (filename, title, added_at, char_count) VALUES (?, ?, ?, ?)",
        (filename, title, datetime.now(timezone.utc).isoformat(), char_count),
    )
    return cur.lastrowid


def insert_chunks(conn: sqlite3.Connection, document_id: int, chunks: list[str]) -> None:
    conn.executemany(
        "INSERT INTO chunks (document_id, chunk_index, text) VALUES (?, ?, ?)",
        [(document_id, i, text) for i, text in enumerate(chunks)],
    )


def fetch_all_chunks(conn: sqlite3.Connection) -> list[sqlite3.Row]:
    return conn.execute(
        """
        SELECT chunks.id AS chunk_id, chunks.document_id, chunks.chunk_index, chunks.text,
               documents.title, documents.filename
        FROM chunks JOIN documents ON documents.id = chunks.document_id
        ORDER BY chunks.id
        """
    ).fetchall()


def fetch_all_documents(conn: sqlite3.Connection) -> list[sqlite3.Row]:
    return conn.execute(
        "SELECT id, filename, title, added_at, char_count FROM documents ORDER BY added_at DESC"
    ).fetchall()


def fetch_document(conn: sqlite3.Connection, document_id: int) -> sqlite3.Row | None:
    return conn.execute(
        "SELECT id, filename, title, added_at, char_count FROM documents WHERE id = ?",
        (document_id,),
    ).fetchone()


def document_exists_by_filename(conn: sqlite3.Connection, filename: str) -> bool:
    row = conn.execute("SELECT 1 FROM documents WHERE filename = ?", (filename,)).fetchone()
    return row is not None


def delete_document(conn: sqlite3.Connection, document_id: int) -> None:
    conn.execute("DELETE FROM documents WHERE id = ?", (document_id,))
