"""Local semantic embedding index built from TF-IDF + Truncated SVD (LSA).

This deliberately avoids downloading any pretrained neural embedding model:
it fits entirely on the user's own corpus, requires no internet access or
GPU, and still captures latent semantic structure well beyond raw keyword
matching -- a good, honest trade-off for a fully offline, reproducible tool.
"""
from __future__ import annotations

import joblib
import numpy as np
from sklearn.decomposition import TruncatedSVD
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import normalize

from app.config import INDEX_DIR, SVD_COMPONENTS

VECTORIZER_PATH = INDEX_DIR / "vectorizer.joblib"
SVD_PATH = INDEX_DIR / "svd.joblib"
VECTORS_PATH = INDEX_DIR / "vectors.npy"
CHUNK_IDS_PATH = INDEX_DIR / "chunk_ids.npy"


class SemanticIndex:
    """Wraps a fitted TF-IDF + SVD pipeline and the resulting document vectors."""

    def __init__(self) -> None:
        self.vectorizer: TfidfVectorizer | None = None
        self.svd: TruncatedSVD | None = None
        self.vectors: np.ndarray | None = None  # shape (n_chunks, n_components), L2-normalized
        self.chunk_ids: np.ndarray | None = None  # shape (n_chunks,)

    @property
    def is_ready(self) -> bool:
        return self.vectors is not None and len(self.vectors) > 0

    def fit(self, chunk_ids: list[int], texts: list[str]) -> None:
        """(Re)fit the index from scratch over the full corpus of chunks.

        Rebuilding on every ingest keeps the implementation simple and is
        cheap at portfolio-project scale (thousands of chunks); a production
        system would instead incrementally update the index.
        """
        if not texts:
            self.vectorizer = None
            self.svd = None
            self.vectors = np.empty((0, 0))
            self.chunk_ids = np.empty((0,), dtype=int)
            return

        # max_df filtering only makes sense once there's a large enough corpus
        # for "appears in almost every document" to be a meaningful signal;
        # on small corpora it can conflict with min_df and raise a ValueError.
        max_df = 0.95 if len(texts) >= 20 else 1.0
        vectorizer = TfidfVectorizer(
            stop_words="english",
            max_df=max_df,
            min_df=1,
            ngram_range=(1, 2),
        )
        tfidf_matrix = vectorizer.fit_transform(texts)
        n_features = tfidf_matrix.shape[1]

        if n_features < 2:
            # Degenerate corpus (e.g. a single near-empty document): SVD needs
            # at least 2 features, so fall back to the raw TF-IDF vectors.
            self.vectorizer = vectorizer
            self.svd = None
            self.vectors = normalize(np.asarray(tfidf_matrix.todense()))
            self.chunk_ids = np.array(chunk_ids, dtype=int)
            return

        n_components = min(SVD_COMPONENTS, max(1, len(texts) - 1), n_features - 1)
        n_components = max(n_components, 1)

        svd = TruncatedSVD(n_components=n_components, random_state=42)
        reduced = svd.fit_transform(tfidf_matrix)
        reduced = normalize(reduced)

        self.vectorizer = vectorizer
        self.svd = svd
        self.vectors = reduced
        self.chunk_ids = np.array(chunk_ids, dtype=int)

    def save(self) -> None:
        INDEX_DIR.mkdir(parents=True, exist_ok=True)
        if self.vectorizer is not None:
            joblib.dump(self.vectorizer, VECTORIZER_PATH)
        if self.svd is not None:
            joblib.dump(self.svd, SVD_PATH)
        if self.vectors is not None:
            np.save(VECTORS_PATH, self.vectors)
        if self.chunk_ids is not None:
            np.save(CHUNK_IDS_PATH, self.chunk_ids)

    def load(self) -> bool:
        if not (VECTORIZER_PATH.exists() and SVD_PATH.exists() and VECTORS_PATH.exists()):
            return False
        self.vectorizer = joblib.load(VECTORIZER_PATH)
        self.svd = joblib.load(SVD_PATH)
        self.vectors = np.load(VECTORS_PATH)
        self.chunk_ids = np.load(CHUNK_IDS_PATH)
        return True

    def transform_query(self, query: str) -> np.ndarray:
        if self.vectorizer is None:
            raise RuntimeError("Index has not been fitted yet.")
        tfidf = self.vectorizer.transform([query])
        if self.svd is None:
            return normalize(np.asarray(tfidf.todense()))[0]
        reduced = self.svd.transform(tfidf)
        return normalize(reduced)[0]

    def similarity_matrix(self) -> np.ndarray:
        """Full pairwise cosine similarity between all chunk vectors."""
        if not self.is_ready:
            return np.empty((0, 0))
        return self.vectors @ self.vectors.T
