"""Document parsing and chunking.

Supports plain text/markdown and PDF input. Chunking uses a sliding window
over words so that semantic context isn't cut off harshly at chunk borders.
"""
from pathlib import Path

from pypdf import PdfReader

from app.config import CHUNK_OVERLAP_WORDS, CHUNK_SIZE_WORDS

SUPPORTED_EXTENSIONS = {".txt", ".md", ".pdf"}


class UnsupportedFileType(Exception):
    pass


def extract_text(file_path: Path) -> str:
    """Extract raw text from a supported document type."""
    suffix = file_path.suffix.lower()
    if suffix in {".txt", ".md"}:
        return file_path.read_text(encoding="utf-8", errors="ignore")
    if suffix == ".pdf":
        reader = PdfReader(str(file_path))
        pages = [page.extract_text() or "" for page in reader.pages]
        return "\n".join(pages)
    raise UnsupportedFileType(f"Unsupported file type: {suffix}")


def chunk_text(
    text: str,
    chunk_size_words: int = CHUNK_SIZE_WORDS,
    overlap_words: int = CHUNK_OVERLAP_WORDS,
) -> list[str]:
    """Split text into overlapping word-window chunks.

    Overlap preserves context across chunk boundaries, which helps retrieval
    when relevant content straddles a cut point.
    """
    words = text.split()
    if not words:
        return []

    if chunk_size_words <= overlap_words:
        raise ValueError("chunk_size_words must be greater than overlap_words")

    chunks = []
    step = chunk_size_words - overlap_words
    for start in range(0, len(words), step):
        window = words[start : start + chunk_size_words]
        if not window:
            break
        chunks.append(" ".join(window))
        if start + chunk_size_words >= len(words):
            break
    return chunks


def derive_title(text: str, fallback: str) -> str:
    """Use the first non-empty line as a title, falling back to the filename."""
    for line in text.splitlines():
        stripped = line.strip().lstrip("#").strip()
        if stripped:
            return stripped[:120]
    return fallback
