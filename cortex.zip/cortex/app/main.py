"""Cortex API -- local semantic document search and knowledge graph engine."""
from __future__ import annotations

import shutil
import tempfile
from pathlib import Path

from contextlib import asynccontextmanager

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from app import database
from app.config import DEFAULT_TOP_K, DOCUMENTS_DIR
from app.embeddings import SemanticIndex
from app.graph import build_document_graph
from app.ingestion import SUPPORTED_EXTENSIONS, UnsupportedFileType, chunk_text, derive_title, extract_text
from app.models import DocumentOut, GraphOut, IngestResponse, SearchResult, StatusResponse
from app.search import search as run_search

# One in-memory index shared across requests; rebuilt whenever the corpus changes.
semantic_index = SemanticIndex()


@asynccontextmanager
async def lifespan(_: FastAPI):
    database.init_db()
    if not semantic_index.load():
        _rebuild_index()
    yield


app = FastAPI(
    title="Cortex",
    description="Local-first semantic search and knowledge graph engine for personal documents.",
    version="1.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


def _rebuild_index() -> None:
    with database.db_session() as conn:
        rows = database.fetch_all_chunks(conn)
    chunk_ids = [row["chunk_id"] for row in rows]
    texts = [row["text"] for row in rows]
    semantic_index.fit(chunk_ids, texts)
    semantic_index.save()


@app.get("/api/status", response_model=StatusResponse)
def get_status() -> StatusResponse:
    with database.db_session() as conn:
        doc_count = len(database.fetch_all_documents(conn))
        chunk_count = len(database.fetch_all_chunks(conn))
    return StatusResponse(document_count=doc_count, chunk_count=chunk_count, index_ready=semantic_index.is_ready)


@app.get("/api/documents", response_model=list[DocumentOut])
def list_documents() -> list[DocumentOut]:
    with database.db_session() as conn:
        rows = database.fetch_all_documents(conn)
    return [DocumentOut(**dict(row)) for row in rows]


@app.delete("/api/documents/{document_id}")
def delete_document(document_id: int) -> dict:
    with database.db_session() as conn:
        doc = database.fetch_document(conn, document_id)
        if doc is None:
            raise HTTPException(status_code=404, detail="Document not found")
        database.delete_document(conn, document_id)
    _rebuild_index()
    return {"deleted": document_id}


@app.post("/api/ingest", response_model=IngestResponse)
async def ingest_document(file: UploadFile = File(...)) -> IngestResponse:
    suffix = Path(file.filename).suffix.lower()
    if suffix not in SUPPORTED_EXTENSIONS:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported file type '{suffix}'. Supported: {sorted(SUPPORTED_EXTENSIONS)}",
        )

    with database.db_session() as conn:
        if database.document_exists_by_filename(conn, file.filename):
            raise HTTPException(status_code=409, detail="A document with this filename was already ingested")

    # Persist the upload to a temp file first, then move it into the managed
    # documents directory only once parsing succeeds.
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        shutil.copyfileobj(file.file, tmp)
        tmp_path = Path(tmp.name)

    try:
        text = extract_text(tmp_path)
    except UnsupportedFileType as exc:
        tmp_path.unlink(missing_ok=True)
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:  # malformed PDF, decode error, etc.
        tmp_path.unlink(missing_ok=True)
        raise HTTPException(status_code=422, detail=f"Failed to parse document: {exc}") from exc

    if not text.strip():
        tmp_path.unlink(missing_ok=True)
        raise HTTPException(status_code=422, detail="Document contains no extractable text")

    chunks = chunk_text(text)
    title = derive_title(text, fallback=file.filename)

    DOCUMENTS_DIR.mkdir(parents=True, exist_ok=True)
    final_path = DOCUMENTS_DIR / file.filename
    shutil.move(str(tmp_path), str(final_path))

    with database.db_session() as conn:
        document_id = database.insert_document(conn, file.filename, title, len(text))
        database.insert_chunks(conn, document_id, chunks)

    _rebuild_index()

    return IngestResponse(document_id=document_id, filename=file.filename, title=title, chunk_count=len(chunks))


@app.get("/api/search", response_model=list[SearchResult])
def search_documents(q: str, top_k: int = DEFAULT_TOP_K) -> list[SearchResult]:
    if not q.strip():
        raise HTTPException(status_code=400, detail="Query parameter 'q' must not be empty")
    with database.db_session() as conn:
        results = run_search(conn, semantic_index, q, top_k=top_k)
    return [SearchResult(**r) for r in results]


@app.get("/api/graph", response_model=GraphOut)
def get_graph() -> GraphOut:
    with database.db_session() as conn:
        graph_data = build_document_graph(conn, semantic_index)
    return GraphOut(**graph_data)


# Serve the frontend as static files, mounted last so it doesn't shadow the API.
STATIC_DIR = Path(__file__).resolve().parent / "static"
app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.get("/")
def serve_index() -> FileResponse:
    return FileResponse(STATIC_DIR / "index.html")
