"""Builds a document-level knowledge graph from chunk-level semantic similarity.

Documents become nodes; an edge is drawn between two documents when any pair
of their chunks is similar enough, which lets two docs connect even if only
part of each is related to the other.
"""
from __future__ import annotations

import sqlite3
from collections import defaultdict

import networkx as nx
import numpy as np

from app.config import GRAPH_MAX_EDGES_PER_NODE, GRAPH_SIMILARITY_THRESHOLD
from app.embeddings import SemanticIndex


def build_document_graph(conn: sqlite3.Connection, index: SemanticIndex) -> dict:
    """Return a JSON-serializable graph: {"nodes": [...], "edges": [...]}."""
    documents = {
        row["id"]: {"title": row["title"], "filename": row["filename"]}
        for row in conn.execute("SELECT id, title, filename FROM documents")
    }

    graph = nx.Graph()
    for doc_id, meta in documents.items():
        graph.add_node(doc_id, **meta)

    if not index.is_ready or len(documents) < 2:
        return _serialize(graph)

    chunk_to_doc = {}
    for row in conn.execute("SELECT id, document_id FROM chunks"):
        chunk_to_doc[row["id"]] = row["document_id"]

    sim = index.similarity_matrix()
    n = sim.shape[0]

    # Best cross-document similarity score per (doc_a, doc_b) pair.
    best_pair_score: dict[tuple[int, int], float] = {}
    for i in range(n):
        doc_i = chunk_to_doc.get(int(index.chunk_ids[i]))
        if doc_i is None:
            continue
        for j in range(i + 1, n):
            doc_j = chunk_to_doc.get(int(index.chunk_ids[j]))
            if doc_j is None or doc_j == doc_i:
                continue
            score = float(sim[i, j])
            if score < GRAPH_SIMILARITY_THRESHOLD:
                continue
            key = (min(doc_i, doc_j), max(doc_i, doc_j))
            if score > best_pair_score.get(key, 0.0):
                best_pair_score[key] = score

    # Cap edges per node to keep the graph readable for dense corpora.
    candidate_edges = defaultdict(list)
    for (a, b), score in best_pair_score.items():
        candidate_edges[a].append((b, score))
        candidate_edges[b].append((a, score))

    added = set()
    for node, neighbors in candidate_edges.items():
        neighbors.sort(key=lambda x: -x[1])
        for other, score in neighbors[:GRAPH_MAX_EDGES_PER_NODE]:
            key = (min(node, other), max(node, other))
            if key in added:
                continue
            added.add(key)
            graph.add_edge(key[0], key[1], weight=round(score, 4))

    return _serialize(graph)


def _serialize(graph: nx.Graph) -> dict:
    nodes = [
        {"id": node_id, "label": data.get("title", str(node_id)), "filename": data.get("filename", "")}
        for node_id, data in graph.nodes(data=True)
    ]
    edges = [
        {"source": u, "target": v, "weight": data.get("weight", 0.0)}
        for u, v, data in graph.edges(data=True)
    ]
    return {"nodes": nodes, "edges": edges}
