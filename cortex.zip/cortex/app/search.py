"""Query-time semantic search over the fitted index."""
from __future__ import annotations

import sqlite3

import numpy as np

from app.config import DEFAULT_TOP_K
from app.embeddings import SemanticIndex


def search(
    conn: sqlite3.Connection,
    index: SemanticIndex,
    query: str,
    top_k: int = DEFAULT_TOP_K,
) -> list[dict]:
    """Return the top-k most semantically similar chunks to the query."""
    query = query.strip()
    if not query:
        return []
    if not index.is_ready:
        return []

    query_vector = index.transform_query(query)
    scores = index.vectors @ query_vector  # cosine similarity, vectors are L2-normalized
    top_k = min(top_k, len(scores))
    top_indices = np.argsort(-scores)[:top_k]

    results = []
    for idx in top_indices:
        score = float(scores[idx])
        if score <= 0:
            continue
        chunk_id = int(index.chunk_ids[idx])
        row = conn.execute(
            """
            SELECT chunks.text, chunks.document_id, chunks.chunk_index,
                   documents.title, documents.filename
            FROM chunks JOIN documents ON documents.id = chunks.document_id
            WHERE chunks.id = ?
            """,
            (chunk_id,),
        ).fetchone()
        if row is None:
            continue
        results.append(
            {
                "chunk_id": chunk_id,
                "document_id": row["document_id"],
                "document_title": row["title"],
                "filename": row["filename"],
                "chunk_index": row["chunk_index"],
                "snippet": _make_snippet(row["text"], query),
                "score": round(score, 4),
            }
        )
    return results


def _make_snippet(text: str, query: str, window: int = 220) -> str:
    """Return a short excerpt centered on the first query-term hit, if any."""
    lower_text = text.lower()
    for term in sorted(query.lower().split(), key=len, reverse=True):
        pos = lower_text.find(term)
        if pos != -1:
            start = max(0, pos - window // 2)
            end = min(len(text), pos + window // 2)
            prefix = "..." if start > 0 else ""
            suffix = "..." if end < len(text) else ""
            return f"{prefix}{text[start:end].strip()}{suffix}"
    return text[:window].strip() + ("..." if len(text) > window else "")
