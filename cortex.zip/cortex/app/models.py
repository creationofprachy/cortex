"""Pydantic schemas for API responses."""
from pydantic import BaseModel


class DocumentOut(BaseModel):
    id: int
    filename: str
    title: str
    added_at: str
    char_count: int


class SearchResult(BaseModel):
    chunk_id: int
    document_id: int
    document_title: str
    filename: str
    chunk_index: int
    snippet: str
    score: float


class GraphNode(BaseModel):
    id: int
    label: str
    filename: str


class GraphEdge(BaseModel):
    source: int
    target: int
    weight: float


class GraphOut(BaseModel):
    nodes: list[GraphNode]
    edges: list[GraphEdge]


class IngestResponse(BaseModel):
    document_id: int
    filename: str
    title: str
    chunk_count: int


class StatusResponse(BaseModel):
    document_count: int
    chunk_count: int
    index_ready: bool
