"""Populate data/documents with a handful of sample notes for a first run.

Run with: python scripts/seed_sample_data.py
Then start the server and the Library tab will already have content to
search and graph.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app import database
from app.config import DOCUMENTS_DIR
from app.ingestion import chunk_text, derive_title

SAMPLES = {
    "neural_networks.txt": (
        "Neural Networks Overview\n\n"
        "Neural networks are computing systems inspired by biological brains. "
        "They consist of layers of interconnected nodes, each transforming its "
        "input through learned weights. Training uses backpropagation to adjust "
        "these weights so the network's predictions get closer to the correct "
        "answer. Deep networks stack many such layers to model complex, "
        "hierarchical patterns in data such as images, text, and audio."
    ),
    "convolutional_networks.txt": (
        "Convolutional Neural Networks\n\n"
        "Convolutional neural networks apply learned filters across an image to "
        "detect local patterns like edges and textures, then combine these into "
        "higher-level features through successive layers. This weight-sharing "
        "makes them efficient for visual tasks such as image classification, "
        "object detection, and medical image analysis."
    ),
    "database_indexing.txt": (
        "Database Indexing Fundamentals\n\n"
        "An index is a data structure that improves the speed of data retrieval "
        "operations on a database table. B-tree and hash indexes are the most "
        "common types. While indexes speed up reads, they add overhead to "
        "writes, so choosing which columns to index requires understanding "
        "query patterns."
    ),
    "distributed_systems.txt": (
        "Consistency in Distributed Systems\n\n"
        "Distributed databases must trade off consistency, availability, and "
        "partition tolerance, as described by the CAP theorem. Many modern "
        "systems choose eventual consistency to remain available during network "
        "partitions, synchronizing replicas asynchronously in the background."
    ),
    "climate_notes.txt": (
        "Notes on Ocean Heat Uptake\n\n"
        "The ocean absorbs the majority of excess heat trapped by greenhouse "
        "gases, buffering atmospheric warming but altering circulation patterns "
        "and accelerating ice sheet melt at the poles over multi-decade "
        "timescales."
    ),
}


def main() -> None:
    database.init_db()
    DOCUMENTS_DIR.mkdir(parents=True, exist_ok=True)

    with database.db_session() as conn:
        for filename, text in SAMPLES.items():
            if database.document_exists_by_filename(conn, filename):
                print(f"skip (already seeded): {filename}")
                continue
            (DOCUMENTS_DIR / filename).write_text(text, encoding="utf-8")
            title = derive_title(text, fallback=filename)
            chunks = chunk_text(text)
            doc_id = database.insert_document(conn, filename, title, len(text))
            database.insert_chunks(conn, doc_id, chunks)
            print(f"seeded: {filename} ({len(chunks)} chunk(s))")

    print("\nDone. Start the server, then open the app and rebuild happens automatically on startup.")


if __name__ == "__main__":
    main()
